import React, { Component } from 'react'

export default class Slider extends Component {
  render() {
    return (
      <div>Slider</div>
    )
  }
}
