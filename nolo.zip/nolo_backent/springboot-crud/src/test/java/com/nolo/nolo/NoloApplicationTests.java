package com.nolo.nolo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NoloApplicationTests {

	@Test
	void contextLoads() {
	}

}
