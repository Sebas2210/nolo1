package com.nolo.nolo;

import org.springframework.data.repository.CrudRepository;

public interface ServiceRepository extends CrudRepository<Service,Integer> {
    
}
