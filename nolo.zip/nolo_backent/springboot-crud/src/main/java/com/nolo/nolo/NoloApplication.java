package com.nolo.nolo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NoloApplication {

	public static void main(String[] args) {
		SpringApplication.run(NoloApplication.class, args);
	}

}
