package com.nolo.nolo;

public class responseDTO {
    boolean state;
    String message;
}
